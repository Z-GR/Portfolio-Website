set(polled_camera_MESSAGE_FILES "")
set(polled_camera_SERVICE_FILES "/home/ma1/catkin_ws/src/image_common/polled_camera/srv/GetPolledImage.srv")
