^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kinect_aux
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------

0.0.1 (2013-12-05)
------------------
* Modified way of finding libusb flags
* Added folder name where libusb.h resides
* Updated README.md: added Travis build image
* Added Travis configuration to repo
* Bumped package version
* Added changelog to repo
* Excluding Eclipse project files from repo with .gitignore
* rosdep install now works
* Allow kinect_aux_node to be installed
* The check for system dependency (libusb) is now done properly
* First commit of catkinised working version for ROS Groovy
* Contributors: Murilo F. M.
