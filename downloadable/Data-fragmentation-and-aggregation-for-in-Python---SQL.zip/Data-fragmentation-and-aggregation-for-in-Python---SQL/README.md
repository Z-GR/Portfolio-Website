# Data fragmentation and aggregation for in Python & SQL

#### How to run
- Install Python 3
- Open the root directory Data_Analytics_In_Python_A_Functional_Approach in an IDE (VS CODE)
- Insert the data set into the Data folder
- Execute the program

#### Report
- Please download the .pdf report for details

 
