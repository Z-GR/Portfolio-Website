/*
* @file ESP8266 Environment Management System
* @brief Client system for EMS
* @author Zak G Rackham
* Contact: zak.g.rackham@gmail.com
*/
#include <DHT11.h>

#include <ESP8266WiFi.h>

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <PubSubClient.h>

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
// The pins for I2C are defined by the Wire-library. 
// On an arduino UNO:       A4(SDA), A5(SCL)
// On an arduino MEGA 2560: 20(SDA), 21(SCL)
// On an arduino LEONARDO:   2(SDA),  3(SCL), ...
#define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3C ///< See datasheet for Address; 0x3D for 128x64, 0x3C for 128x32
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

#define WIFI_NAME "Home_2.4G"
#define WIFI_PASSWORD "Homenet.150"

WiFiClient espClient;
PubSubClient client;
unsigned long lastMsg = 0;
unsigned long lastMsg1 = 0;
#define MSG_BUFFER_SIZE	(50)
char msg[MSG_BUFFER_SIZE];
char msg1[MSG_BUFFER_SIZE];
int value = 0;

int temperature = 0;
int humidity = 0;

int count = 0;

// Create an instance of the DHT11 class.
// - For Arduino: Connect the sensor to Digital I/O Pin 2.
// - For ESP32: Connect the sensor to pin GPIO2 or P2.
// - For ESP8266: Connect the sensor to GPIO2 or D4.
DHT11 dht11(2);

int fansys = 14;
bool fanstate = false;
bool humidifierstate = false;

void setup() {
  pinMode(2, OUTPUT);     // Initialize the LED_BUILTIN pin as an output
  pinMode(14, OUTPUT);    // Initialise the RELAY_TRIGGER pin as an output
  pinMode(0, OUTPUT);    // Initialise the RELAY_TRIGGER pin as an output


  Serial.begin(9600);

  // SSD1306_SWITCHCAPVCC = generate display voltage from 3.3V internally
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
  }

  // Show initial display buffer contents on the screen --
  // the library initializes this with an Adafruit splash screen.
  display.display();
  delay(2000); // Pause for 2 seconds

  // Clear the buffer
  display.clearDisplay();

  // Draw a single pixel in white
  display.drawPixel(10, 10, SSD1306_WHITE);

  // Show the display buffer on the screen. You MUST call display() after
  // drawing commands to make them visible on screen!
  display.display();
  delay(2000);
  // display.display() is NOT necessary after every single drawing command,
  // unless that's what you want...rather, you can batch up a bunch of
  // drawing operations and then update the screen all at once by calling
  // display.display(). These examples demonstrate both approaches...

  //testdrawrect();      // Draw rectangles (outlines)

  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);

  Serial.print("Connecting");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
  Serial.println();

  Serial.print("Connected, IP address: ");
  Serial.println(WiFi.localIP());

  //Setup the pubsub client connection

  client.setClient(espClient);
    client.setServer("192.168.0.7",1883);
    client.setCallback(callback);
    // client is now configured for use

  updatetext(); //Boot info screen

}

void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]);
  }
  Serial.println();

  // Switch on the LED if an 1 was received as first character
  if ((char)payload[0] == '1') {
    Serial.print("Message arrived = 1");
    fanstate = true;

  } 
  
  // Switch on the LED if an 1 was received as first character
  if ((char)payload[0] == '0') {
    Serial.print("Message arrived = 0");
    fanstate = false;
  }

  if ((char)payload[0] == '2') {
    Serial.print("Message arrived = 2");
    humidifierstate = true;

  } 

  if ((char)payload[0] == '3') {
    Serial.print("Message arrived = 3");
    humidifierstate = false;
  } 
}

void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // Create a random client ID
    String clientId = "ESP8266Client-";
    clientId += String(random(0xffff), HEX);
    yield();
    // Attempt to connect
    if (client.connect(clientId.c_str())) {
      Serial.println("connected");
      yield();
      // Once connected, publish an announcement...
      client.publish("outTopic", "EMS Online");
      // ... and resubscribe
      client.subscribe("inTopic");
      client.subscribe("emsSetFan", 0);
      client.subscribe("emsSetHumidifier", 0);
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again on next execution");
      // Wait 5 seconds before retrying
      delay(1000);
      break;
    }
  }
}

void testdrawrect(void) {
  display.clearDisplay();

  for(int16_t i=0; i<display.height()/2; i+=2) {
    display.drawRect(i, i, display.width()-2*i, display.height()-2*i, SSD1306_WHITE);
    display.display(); // Update screen with each newly-drawn rectangle
    delay(1);
  }

  delay(2000);
}

void updatetext(void) {
  display.clearDisplay();

  display.setTextSize(1);             // Normal 1:1 pixel scale
  display.setTextColor(SSD1306_WHITE);        // Draw white text
  display.setCursor(0,0);             // Start at top-left corner
  display.setTextSize(2);
  display.println(F("EMS v1.1"));

  display.setTextSize(1);
  display.println("By Zak G Rackham");

  display.display();
  delay(2000);

}

void updatedht11display(void) {
  display.clearDisplay();
  display.cp437(true);  // Use correct CP437 character codes

  display.setTextSize(1);             // Normal 1:1 pixel scale
  display.setTextColor(SSD1306_WHITE);        // Draw white text
  display.setCursor(0,0);             // Start at top-left corner
  display.setTextSize(2);
  display.print(F("T: "));
  display.print(temperature);
  display.write(0xF8);
  display.println();
  display.println();
  display.println();

  display.setTextSize(2);
  display.print("H: ");
  display.print(humidity);

  display.display();
  delay(2000);

}

void readdht() {
  // Attempt to read the temperature and humidity values from the DHT11 sensor.
  int result = dht11.readTemperatureHumidity(temperature, humidity);

  // Check the results of the readings.
  // If the reading is successful, print the temperature and humidity values.
  // If there are errors, print the appropriate error messages.
  if (result == 0) {
      Serial.print("Temperature: ");
      Serial.print(temperature);
      Serial.print(" °C\tHumidity: ");
      Serial.print(humidity);
      Serial.println(" %");
  } else {
      // Print error message based on the error code.
      Serial.println(DHT11::getErrorString(result));
      yield();
  }

}

void publishtemp() {

  unsigned long now = millis();
  if (now - lastMsg > 2000) {
    lastMsg = now;
    ++value;
    snprintf (msg, MSG_BUFFER_SIZE, "%ld", temperature);
    Serial.print("Publish message: ");
    Serial.println(msg);
    client.publish("emsTemperature", msg);
  }
}

void publishhum() {

  unsigned long now1 = millis();
  if (now1 - lastMsg1 > 2000) {
    lastMsg1 = now1;
    ++value;
    snprintf (msg1, MSG_BUFFER_SIZE, "%ld", humidity);
    Serial.print("Publish message: ");
    Serial.println(msg1);
    client.publish("emsHumidity", msg1);
  }

}
 
// the loop function runs over and over again forever
void loop() {
  ++count;

  switch (count) {
  case 1:
    readdht();
    updatedht11display();
    break;
  case 2:
    client.loop();
    yield();
    break;
  case 3:
    publishtemp();
    break;
  case 4:
    publishhum();
    break;
  case 5:
    if (!client.connected()) {
      reconnect();
    }
    count = 0;
    break;
}

  if (!fanstate){
    //Turn on cooling auto
    if (temperature > 25 && humidity > 50){
      digitalWrite(14, HIGH);
    }
    else {
      digitalWrite(14, LOW);
    }
  } else {
    //Turn on cooling manual
    digitalWrite(14, HIGH);
  }

  if (!humidifierstate){
    //Turn on cooling auto
    if (humidity < 50){
      digitalWrite(0, HIGH);
    }
    else {
      digitalWrite(0, LOW);
    }
  } else {
    //Turn on cooling manual
    digitalWrite(0, HIGH);
  }

  yield();
}