# Terrarium_Environment_Management_System
 IoT device based on node MCU v3.0
## Built using arduino

## Additional Boards URL
Arduino IDE requires a URL for Node MCU compatibility. Enter this URL under preferences on the arduino IDE.

https://arduino.esp8266.com/stable/package_esp8266com_index.json

**Board used for this project:** ESP8266 ESP-12F NodeMCU Module V3

## Node MCU Firmware
Flash the firmware to the board before programming.

https://github.com/marcelstoer/nodemcu-pyflasher/releases

## Arduino libarys

Install the required dependencies for each.

https://github.com/dhrubasaha08/DHT11

https://github.com/adafruit/Adafruit-GFX-Library.git

https://github.com/adafruit/Adafruit_SSD1306.git

http://pubsubclient.knolleary.net/


## Mosquitto MQTT
A message broker is required to use the device.

### Update system packages

```
sudo apt-get update -y
sudo apt-get upgrade -y
```

### Install Mosquitto

```
sudo apt-get install mosquitto mosquitto-clients -y
```

### Configure Mosquitto

```
sudo nano /etc/mosquitto/mosquitto.conf
```

Start and Enable Mosquitto

```
sudo systemctl start mosquitto
sudo systemctl enable mosquitto

```